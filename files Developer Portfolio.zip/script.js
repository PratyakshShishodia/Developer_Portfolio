/* ============================================================
   PORTFOLIO — script.js
   Features: Loader, Particles, Typed.js, Cursor, Scroll effects,
             Dark/Light toggle, Hamburger, Skill bars, Project filter,
             Form validation, Scroll reveal, Smooth nav highlight
   ============================================================ */

/* ---- LOADER ---- */
(function () {
  const loader = document.getElementById('loader');
  const bar    = document.getElementById('loaderBar');
  const text   = document.getElementById('loaderText');
  const steps  = [
    [20,  'Parsing HTML...'],
    [45,  'Loading styles...'],
    [70,  'Running scripts...'],
    [90,  'Rendering UI...'],
    [100, 'Ready!'],
  ];
  let i = 0;
  const tick = setInterval(() => {
    if (i >= steps.length) {
      clearInterval(tick);
      setTimeout(() => {
        loader.classList.add('hidden');
        document.body.style.overflow = '';
        triggerHeroAnimations();
      }, 300);
      return;
    }
    const [pct, msg] = steps[i++];
    bar.style.width = pct + '%';
    text.textContent = msg;
  }, 350);
  document.body.style.overflow = 'hidden';
})();

/* ---- PARTICLE BACKGROUND ---- */
(function () {
  const canvas = document.getElementById('particleCanvas');
  const ctx    = canvas.getContext('2d');
  let W, H, particles = [], mouse = { x: -9999, y: -9999 };
  const MAX = 80, CONNECT = 120;

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  function color() {
    return document.body.dataset.theme === 'light' ? '37,99,235' : '99,179,237';
  }

  class Particle {
    constructor() { this.reset(); }
    reset() {
      this.x  = Math.random() * W;
      this.y  = Math.random() * H;
      this.vx = (Math.random() - 0.5) * 0.4;
      this.vy = (Math.random() - 0.5) * 0.4;
      this.r  = Math.random() * 1.8 + 0.6;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      if (this.x < 0 || this.x > W) this.vx *= -1;
      if (this.y < 0 || this.y > H) this.vy *= -1;
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${color()},0.7)`;
      ctx.fill();
    }
  }

  for (let i = 0; i < MAX; i++) particles.push(new Particle());

  window.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });

  function loop() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => { p.update(); p.draw(); });

    // Connect close particles
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const d  = Math.sqrt(dx * dx + dy * dy);
        if (d < CONNECT) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(${color()},${0.15 * (1 - d / CONNECT)})`;
          ctx.lineWidth = 0.7;
          ctx.stroke();
        }
      }
      // Mouse connect
      const dx = particles[i].x - mouse.x;
      const dy = particles[i].y - mouse.y;
      const d  = Math.sqrt(dx * dx + dy * dy);
      if (d < 150) {
        ctx.beginPath();
        ctx.moveTo(particles[i].x, particles[i].y);
        ctx.lineTo(mouse.x, mouse.y);
        ctx.strokeStyle = `rgba(${color()},${0.3 * (1 - d / 150)})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }
    }
    requestAnimationFrame(loop);
  }
  loop();
})();

/* ---- CUSTOM CURSOR ---- */
(function () {
  const dot  = document.getElementById('cursorDot');
  const ring = document.getElementById('cursorRing');
  if (!dot || !ring) return;

  let rx = 0, ry = 0;

  window.addEventListener('mousemove', e => {
    dot.style.left  = e.clientX + 'px';
    dot.style.top   = e.clientY + 'px';
    rx += (e.clientX - rx) * 0.12;
    ry += (e.clientY - ry) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
  });

  // Lerp ring
  function lerpRing() {
    requestAnimationFrame(lerpRing);
    ring.style.left = rx + 'px';
    ring.style.top  = ry + 'px';
  }
  lerpRing();

  document.querySelectorAll('a,button,.skill-card,.project-card,.profile-card').forEach(el => {
    el.addEventListener('mouseenter', () => ring.classList.add('hovered'));
    el.addEventListener('mouseleave', () => ring.classList.remove('hovered'));
  });
})();

/* ---- TYPED TEXT EFFECT ---- */
(function () {
  const el    = document.getElementById('typedText');
  if (!el) return;
  const words = [
    'Software Developer',
    'Data Analyst',
    'ML Engineer',
    'Full Stack Dev',
    'Problem Solver',
    'Open Source Contributor',
  ];
  let wi = 0, ci = 0, deleting = false, timeout;

  function type() {
    const word = words[wi];
    if (!deleting) {
      el.textContent = word.slice(0, ++ci);
      if (ci === word.length) { deleting = true; timeout = 2000; }
      else timeout = 85;
    } else {
      el.textContent = word.slice(0, --ci);
      if (ci === 0) { deleting = false; wi = (wi + 1) % words.length; timeout = 400; }
      else timeout = 45;
    }
    setTimeout(type, timeout);
  }
  setTimeout(type, 1200);
})();

/* ---- HERO ANIMATION TRIGGER ---- */
function triggerHeroAnimations() {
  const items = document.querySelectorAll('.hero-greeting,.hero-name,.hero-role,.hero-bio,.hero-btns,.hero-socials,.hero-visual,.scroll-hint');
  items.forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    setTimeout(() => {
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    }, i * 100 + 200);
  });
}

/* ---- NAVBAR SCROLL & ACTIVE ---- */
(function () {
  const nav     = document.getElementById('navbar');
  const links   = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');

  function onScroll() {
    nav.classList.toggle('scrolled', window.scrollY > 40);

    let current = '';
    sections.forEach(sec => {
      if (window.scrollY >= sec.offsetTop - 100) current = sec.id;
    });
    links.forEach(l => {
      l.classList.toggle('active', l.getAttribute('href') === '#' + current);
    });
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ---- HAMBURGER MENU ---- */
(function () {
  const btn   = document.getElementById('hamburger');
  const menu  = document.getElementById('navLinks');
  if (!btn || !menu) return;
  btn.addEventListener('click', () => {
    btn.classList.toggle('active');
    menu.classList.toggle('open');
  });
  document.querySelectorAll('.nav-link').forEach(l => {
    l.addEventListener('click', () => {
      btn.classList.remove('active');
      menu.classList.remove('open');
    });
  });
})();

/* ---- DARK / LIGHT TOGGLE ---- */
(function () {
  const btn  = document.getElementById('themeToggle');
  const icon = document.getElementById('themeIcon');
  const body = document.body;
  if (!btn) return;

  const saved = localStorage.getItem('portfolio-theme') || 'dark';
  applyTheme(saved);

  btn.addEventListener('click', () => {
    const next = body.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    localStorage.setItem('portfolio-theme', next);
  });

  function applyTheme(t) {
    body.dataset.theme = t;
    body.classList.toggle('dark-mode', t === 'dark');
    icon.className = t === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
  }
})();

/* ---- SCROLL REVEAL ---- */
(function () {
  const els = document.querySelectorAll('.reveal');
  const io  = new IntersectionObserver((entries) => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => e.target.classList.add('visible'), 60);
        io.unobserve(e.target);

        // Trigger skill bars when skills section becomes visible
        if (e.target.classList.contains('skill-card')) {
          const fill = e.target.querySelector('.skill-fill');
          if (fill) {
            setTimeout(() => {
              fill.style.width = fill.dataset.width + '%';
            }, 100);
          }
        }
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  els.forEach(el => io.observe(el));
})();

/* ---- PROJECT FILTER ---- */
(function () {
  const btns  = document.querySelectorAll('.filter-btn');
  const cards = document.querySelectorAll('.project-card');

  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const f = btn.dataset.filter;
      cards.forEach(card => {
        const match = f === 'all' || card.dataset.category === f;
        card.classList.toggle('hidden', !match);
        if (match) {
          card.style.animation = 'none';
          card.offsetHeight; // reflow
          card.style.animation = 'fadeInUp 0.4s ease forwards';
        }
      });
    });
  });
})();

/* ---- CONTACT FORM VALIDATION ---- */
(function () {
  const form    = document.getElementById('contactForm');
  if (!form) return;
  const fields  = {
    name:    { el: document.getElementById('name'),    err: document.getElementById('nameError'),    min: 2,   label: 'Name' },
    email:   { el: document.getElementById('email'),   err: document.getElementById('emailError'),   type:'email', label: 'Email' },
    subject: { el: document.getElementById('subject'), err: document.getElementById('subjectError'), min: 3,   label: 'Subject' },
    message: { el: document.getElementById('message'), err: document.getElementById('messageError'), min: 10,  label: 'Message' },
  };
  const success = document.getElementById('formSuccess');
  const submitBtn = document.getElementById('submitBtn');

  function validateField(key) {
    const { el, err, min, type } = fields[key];
    const val = el.value.trim();
    if (!val) { err.textContent = `${fields[key].label} is required.`; return false; }
    if (type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
      err.textContent = 'Please enter a valid email.'; return false;
    }
    if (min && val.length < min) { err.textContent = `At least ${min} characters required.`; return false; }
    err.textContent = '';
    return true;
  }

  Object.keys(fields).forEach(key => {
    fields[key].el.addEventListener('input', () => validateField(key));
    fields[key].el.addEventListener('blur',  () => validateField(key));
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    const valid = Object.keys(fields).map(validateField).every(Boolean);
    if (!valid) return;

    // Simulate send
    submitBtn.disabled = true;
    document.getElementById('btnText').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

    setTimeout(() => {
      form.reset();
      submitBtn.disabled = false;
      document.getElementById('btnText').innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
      success.classList.add('show');
      setTimeout(() => success.classList.remove('show'), 4000);
    }, 1800);
  });
})();

/* ---- SMOOTH SCROLL ---- */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: 'smooth' });
  });
});

/* ---- KEYFRAME (add to doc) ---- */
const style = document.createElement('style');
style.textContent = `
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}`;
document.head.appendChild(style);
