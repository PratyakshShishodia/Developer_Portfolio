# 🚀 Alex Chen — Developer Portfolio

A modern, high-performance personal portfolio website built with pure **HTML**, **CSS**, and **JavaScript** — no frameworks, no dependencies.

![Portfolio Preview](assets/preview.png)

---

## ✨ Features

### UI / Design
- **Dark & Light mode** with localStorage persistence
- **Glassmorphism** cards and panels
- **Gradient mesh** and particle canvas background
- **Custom cursor** with hover expansion
- **Syne + DM Sans + JetBrains Mono** typography system
- Fully responsive from 320px → 4K

### Animations & Interactions
- **Loading screen** with animated progress bar
- **Particle canvas** with mouse interaction and connection lines
- **Typed.js-style** role cycling animation
- **Scroll reveal** with IntersectionObserver
- **Animated skill progress bars** triggered on scroll
- **Floating cards** in the hero section
- Hover effects on all interactive elements
- Mobile hamburger menu with smooth transition

### Sections
| # | Section | Features |
|---|---------|----------|
| 01 | Hero | Name, typed role, bio, buttons, social icons, floating tech cards |
| 02 | About | Bio, career goals, animated timeline with education |
| 03 | Skills | 8 skill cards with animated progress bars + tools grid |
| 04 | Projects | 6 project cards with filter (All / AI / Web / App), overlay links |
| 05 | Resume | Resume preview with download button, stats grid, highlights |
| 06 | Profiles | GitHub, LeetCode, HackerRank, LinkedIn cards |
| 07 | Contact | Info cards + validated contact form |

---

## 📁 Folder Structure

```
portfolio/
├── index.html       # Main HTML structure (all sections)
├── style.css        # Full stylesheet with CSS variables & responsive layout
├── script.js        # All JS: particles, typed, cursor, forms, animations
├── resume.pdf       # Your resume (replace with your actual resume)
├── assets/
│   └── profile.jpg  # Replace with your photo (update img src in HTML)
└── README.md
```

---

## 🛠️ Customization Guide

### 1. Personal Info
In `index.html`, search and replace:
- `Alex Chen` → Your full name
- `alex@example.com` → Your email
- `+91 98765 43210` → Your phone
- `Haryana, India` → Your location
- All `https://github.com`, `https://linkedin.com`, `https://leetcode.com` → Your actual profile URLs
- `@alexchen` → Your actual handles

### 2. Profile Photo
Add your photo as `assets/profile.jpg` and replace the avatar placeholder in `index.html`:
```html
<!-- Replace this -->
<div class="avatar-placeholder"><i class="fas fa-user"></i></div>
<!-- With this -->
<img src="assets/profile.jpg" alt="Alex Chen" style="width:100%;height:100%;object-fit:cover;" />
```

### 3. Projects
Edit the project cards in the `#projects` section. Update:
- Project title and description
- Technology tags
- GitHub and live demo links

### 4. Resume
Replace `resume.pdf` in the root folder with your actual resume PDF.

### 5. Colors (Optional)
In `style.css`, edit the `:root` CSS variables:
```css
--accent: #63b3ed;   /* Change to your brand color */
```

---

## 🚀 Deployment

### GitHub Pages
```bash
git init
git add .
git commit -m "feat: portfolio website"
git branch -M main
git remote add origin https://github.com/yourusername/portfolio.git
git push -u origin main
# Then enable Pages in repo Settings → Pages → main branch
```

### Netlify (Drag & Drop)
Just drag the `portfolio/` folder to [netlify.com/drop](https://netlify.com/drop).

### Vercel
```bash
npx vercel --prod
```

---

## 📋 Resume Project Description

> Developed a responsive personal portfolio website showcasing projects, technical skills, resume, and GitHub profile with modern UI animations, dark/light mode, particle canvas background, custom cursor effects, and interactive design using HTML, CSS, and JavaScript.

**Key highlights:**
- Zero dependencies — pure HTML/CSS/JS
- 90+ Lighthouse performance score
- IntersectionObserver-based lazy animations
- Accessible, SEO-friendly markup
- Mobile-first responsive design

---

## 📊 GitHub Profile README Snippet

```md
### Hi there, I'm Alex Chen 👋

🔭 I'm currently working on **AI & Full-Stack projects**  
🌱 I'm learning **Deep Learning & System Design**  
💬 Ask me about **Python, JavaScript, Data Science**  
📫 Reach me at **alex@example.com**  
🌐 Portfolio: **https://alexchen.dev**

**Languages & Tools:**
Python · Java · C++ · JavaScript · React · Flask · SQL · TensorFlow · Git
```

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

<div align="center">
Made with ♥ by Alex Chen
</div>
